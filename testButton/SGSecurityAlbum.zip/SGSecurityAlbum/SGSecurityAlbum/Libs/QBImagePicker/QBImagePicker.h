//
//  QBImagePicker.h
//  QBImagePicker
//
//  Created by Katsuma Tanaka on 2015/04/03.
//  Copyright (c) 2015 Katsuma Tanaka. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for QBImagePicker.
FOUNDATION_EXPORT double QBImagePickerVersionNumber;

//! Project version string for QBImagePicker.
FOUNDATION_EXPORT const unsigned char QBImagePickerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QBImagePicker/PublicHeader.h>
#import <QBImagePicker/QBImagePickerController.h>
