//
//  NSString+MD5.h
//  随机数大作战
//
//  Created by 11 on 8/14/15.
//  Copyright (c) 2015 soulghost. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MD5)

- (NSString *)MD5;

@end
