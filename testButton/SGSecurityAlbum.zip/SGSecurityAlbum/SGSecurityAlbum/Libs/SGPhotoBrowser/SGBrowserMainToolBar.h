//
//  SGBrowserMainToolBar.h
//  SGSecurityAlbum
//
//  Created by soulghost on 13/7/2016.
//  Copyright © 2016 soulghost. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SGBlockToolBar.h"
#import "SGBrowserToolBar.h"

@interface SGBrowserMainToolBar : SGBlockToolBar

@end
