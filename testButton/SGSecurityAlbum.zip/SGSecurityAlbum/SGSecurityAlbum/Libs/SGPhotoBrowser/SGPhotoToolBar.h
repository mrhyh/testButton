//
//  SGPhotoToolBar.h
//  SGSecurityAlbum
//
//  Created by soulghost on 12/7/2016.
//  Copyright © 2016 soulghost. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SGBlockToolBar.h"

#define SGPhotoToolBarTrashTag -1
#define SGPhotoToolBarExportTag -2

@interface SGPhotoToolBar : SGBlockToolBar

@end
