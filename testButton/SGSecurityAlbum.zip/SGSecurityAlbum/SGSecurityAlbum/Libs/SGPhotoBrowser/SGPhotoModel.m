//
//  SGPhoto.m
//  SGSecurityAlbum
//
//  Created by soulghost on 10/7/2016.
//  Copyright © 2016 soulghost. All rights reserved.
//

#import "SGPhotoModel.h"

@implementation SGPhotoModel

@end
