//
//  SGRegisterViewController.h
//  SGSecurityAlbum
//
//  Created by soulghost on 8/7/2016.
//  Copyright © 2016 soulghost. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SGRegisterViewController : UIViewController

@end
