//
//  SGAlbum.m
//  SGSecurityAlbum
//
//  Created by soulghost on 9/7/2016.
//  Copyright © 2016 soulghost. All rights reserved.
//

#import "SGAlbum.h"

@implementation SGAlbum

@end
